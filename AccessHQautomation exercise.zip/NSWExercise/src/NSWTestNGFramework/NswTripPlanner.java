package NSWTestNGFramework;

import org.testng.annotations.*;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class NswTripPlanner {

	private WebDriver driver;

	@BeforeTest

	public void BeforeTest() {

		// To take care of MAC or other operating systems
		String os = System.getProperty("os.name").toLowerCase();

		if (os.contains("mac")) {

			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/chromedriver");

		} else {

			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "\\chromedriver.exe");
		}

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(45, TimeUnit.SECONDS);
		String url = "https://transportnsw.info/trip";
		driver.get(url);

	}

	@AfterTest
	// Close the browser and all tabs
	public void afterTest() {
		try {
			Thread.sleep(6000);
		} catch (InterruptedException e) {

			e.printStackTrace();
		}
		driver.quit();
	}

	@Test
	@Parameters({ "FromDestination", "ToDestination" })

	public void tripRequest(String FromDestination, String ToDestination) {

		try {
			Thread.sleep(2000);
			driver.findElement(By.id("search-input-From")).sendKeys(FromDestination);
			Thread.sleep(2000);
			driver.findElement(By.id("search-input-To")).sendKeys(ToDestination);
			Thread.sleep(2000);
			driver.findElement(By.id("search-button")).click();

		} catch (InterruptedException e) {

			e.printStackTrace();
		}
	}

}
